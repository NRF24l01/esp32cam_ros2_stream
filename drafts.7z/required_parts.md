# Parts reqired:
## 3D printring
- `camera_fixer.stl` - 1 pcs
- `fixer.stl` - 1 pcs
- `main_part.stl` - 1 pcs
